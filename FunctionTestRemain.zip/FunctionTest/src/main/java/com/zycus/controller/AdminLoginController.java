package com.zycus.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.entity.AdminCredentials;
import com.zycus.service.AdminLoginService;

@Controller

public class AdminLoginController {

    @Autowired
    AdminLoginService service;
    

    
    @RequestMapping(value="/adminlogin", method = RequestMethod.GET)
    public String showLoginPage(ModelMap model){
        
    
    	return "adminloginpage";
    
    }

    @RequestMapping(value="/adminlogin", method = RequestMethod.POST,consumes = "application/json", produces="text/plain")
    public @ResponseBody String showWelcomePage(@RequestBody AdminCredentials adcred, HttpServletRequest request){

        boolean isValidUser = service.validateUser(adcred.getUsername(),adcred.getPassword());

        
        if (!isValidUser) {
            return "fail";
        }
        request.getSession().setAttribute("user", adcred.getUsername());
        return "success";
    }

    @RequestMapping(value="/welcomeadmin", method = RequestMethod.GET)
    public String showWelcomePage(ModelMap model, HttpServletRequest request){
    	
    	
    	
    	
    	if(request.getSession().getAttribute("user") == null){
    		
    		return "redirect:/adminlogin";
    	}
    	model.put("username", request.getSession().getAttribute("user") );
    	return "welcomeadminpage";
    
    }
    @RequestMapping(value="/adminlogout", method = RequestMethod.GET)
    public String backtologin(ModelMap model ,HttpServletRequest request){
    	
    	request.getSession().invalidate();
    	return "redirect:/adminlogin";
    
    }
}