package com.zycus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.entity.Category;
import com.zycus.service.AdminCategoryService;

@Controller
public class CategoryController {

	@Autowired
	AdminCategoryService categoryService;
	

	@RequestMapping(value = "/addcategory", method = RequestMethod.POST, consumes = "application/json", produces="text/plain")
	public String createCategory(@RequestBody Category category){
		
	
		System.out.println(category);
		categoryService.registerCategory(category);
		return "success";
	}
	
}
