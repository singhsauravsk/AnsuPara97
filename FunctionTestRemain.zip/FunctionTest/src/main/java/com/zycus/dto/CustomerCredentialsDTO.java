package com.zycus.dto;

public class CustomerCredentialsDTO {

	public String customerName;
	public String password;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "CustomerCredentialsDTO [customerName=" + customerName + ", password=" + password + "]";
	}
	public CustomerCredentialsDTO(String customerName, String password) {
		super();
		this.customerName = customerName;
		this.password = password;
	}
	public CustomerCredentialsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
