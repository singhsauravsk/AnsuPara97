package com.zycus.entity;

import com.fasterxml.jackson.annotation.JsonCreator;

public class AdminCredentials {

	public String username;
	public String password;
	
	
	
	public AdminCredentials(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	@Override
	public String toString() {
		return "AdminCredentials [username=" + username + ", password=" + password + "]";
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public AdminCredentials() {
		super();
	}
	
	
}
