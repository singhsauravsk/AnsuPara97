package com.zycus.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_CUSTOMERCREDENTIALS")
public class CustomerCredentials {

	@Id
	@GeneratedValue
	public int customerID;
	
	public String customerName;
	public String address;
	public String password;
	public int contactNo;
	public String emailId;
	
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public CustomerCredentials() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerCredentials(int customerID, String customerName, String address, String password, int contactNo, String emailId) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.address = address;
		this.password = password;
		this.contactNo = contactNo;
		this.emailId = emailId;
		
	}
	@Override
	public String toString() {
		return "CustomerCredentials [customerID=" + customerID + ", customerName=" + customerName + ", address="
				+ address + ", password=" + password + ", contactNo=" + contactNo + ", emailId=" + emailId + "]";
	}
	
	
}
