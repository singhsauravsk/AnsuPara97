package com.zycus.repository;

import org.springframework.data.repository.CrudRepository;

import com.zycus.entity.Category;

public interface AdminCategoryRepository extends CrudRepository<Category, Integer> {

}
