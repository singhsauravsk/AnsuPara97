package com.zycus.repository;

import org.springframework.data.repository.CrudRepository;

import com.zycus.entity.Category;
import com.zycus.entity.CustomerCredentials;

public interface CustomerCredentialsRepository extends CrudRepository<CustomerCredentials, Integer> {

}
