package com.zycus.service;

import com.zycus.entity.Category;

public interface AdminCateService {
	
	void registerCategory (Category category);
	Iterable <Category> getAllcategory();
}
