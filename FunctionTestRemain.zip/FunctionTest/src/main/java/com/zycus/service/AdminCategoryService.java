package com.zycus.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.entity.Category;
import com.zycus.repository.AdminCategoryRepository;

@Service
@Transactional
public class AdminCategoryService implements AdminCateService {

	@Autowired
	AdminCategoryRepository adminCategoryRepository;
	
	public void registerCategory(Category adminCategory) {
	
		adminCategoryRepository.save(adminCategory);
		
	}

	public Iterable<Category> getAllcategory() {
		return adminCategoryRepository.findAll();
	}

}