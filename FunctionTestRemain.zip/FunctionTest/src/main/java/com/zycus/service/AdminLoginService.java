package com.zycus.service;

import org.springframework.stereotype.Service;

@Service
public class AdminLoginService {

    public boolean validateUser(String userid, String password) {
       
        return userid.equals("admin") && password.equals("password");
    }

}