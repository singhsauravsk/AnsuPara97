package com.zycus.service;

import com.zycus.entity.Category;
import com.zycus.entity.CustomerCredentials;

public interface CustSignupService {

	void registerCustomer (CustomerCredentials customerCredentials);

}
