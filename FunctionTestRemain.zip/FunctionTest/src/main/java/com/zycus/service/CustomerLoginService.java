package com.zycus.service;

import org.springframework.stereotype.Service;

@Service
public class CustomerLoginService {

	 public boolean validateUser(String userid, String password) {
	       
	        return userid.equals("customer") && password.equals("password");
	    }
}
