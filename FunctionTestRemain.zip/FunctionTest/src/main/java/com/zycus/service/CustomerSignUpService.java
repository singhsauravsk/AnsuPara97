package com.zycus.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.entity.CustomerCredentials;
import com.zycus.repository.CustomerCredentialsRepository;

@Service
@Transactional
public class CustomerSignUpService implements CustSignupService{

	@Autowired
	CustomerCredentialsRepository customerCredentialsRepository;
	
	@Override
	public void registerCustomer(CustomerCredentials customerCredentials) {
		
		customerCredentialsRepository.save(customerCredentials);
	
	}


}
