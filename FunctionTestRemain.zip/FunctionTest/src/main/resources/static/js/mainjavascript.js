/**
 * 
 */
/*------------------------------------Admin LOGIN-----------------------------------------*/
$(function() {
			
			$("#adminLoginform").submit(function(event) {
				event.preventDefault();
				
				var loginObj = {
						username : $("#username").val(),
						password : $("#password").val(),
				}
				
				var loginObjectJson = JSON.stringify(loginObj);
				console.log(loginObjectJson);
				
				var request = $.ajax({
					url : "/adminlogin",
					method : "POST",
					data : loginObjectJson,
					contentType : "application/json"
				})
				
				
				request.done(function(data){
					
					if(data == "success") {
						window.location = "/welcomeadmin";
					}
					else{
						alert ("The username or password doesn't match\n ERROR!!!");
						window.location.reload(true);
					}
				})
				
				request.fail(function(jqXHR, textStatus){
					console.log("FAIL:  "+textStatus+" || "+jqXHR);
				})
			})
		})
/*----------------------------------customer login----------------------------------------------------------------*/
		$(function() {
			
			$("#customerlogin").submit(function(event) {
				event.preventDefault();
				
				var loginObj = {
						username : $("#username").val(),
						password : $("#password").val(),
				}
				
				var loginObjectJson = JSON.stringify(loginObj);
				console.log(loginObjectJson);
				
				var request = $.ajax({
					url : "/adminlogin",
					method : "POST",
					data : loginObjectJson,
					contentType : "application/json"
				})
				
				
				request.done(function(data){
					
					if(data == "success") {
						window.location = "/welcomeadmin";
					}
					else{
						alert ("The username or password doesn't match\n ERROR!!!");
						window.location.reload(true);
					}
				})
				
				request.fail(function(jqXHR, textStatus){
					console.log("FAIL:  "+textStatus+" || "+jqXHR);
				})
			})
		})
		

		
		
		
		
		
/*------------------------------------CATEGORY ADD FORM-----------------------------------------*/		
$(function() {
			
			$("#category-form").submit(function(event) {
				event.preventDefault();
				
				var categoryObj = {
						category : $("#category").val(),
						parentCategory : $("#parentCategory").val()
				}
				
				var categoryJson = JSON.stringify(categoryObj);
				console.log(categoryJson);
				
				var request = $.ajax({
					url : "/addcategory",
					method : "POST",
					data : categoryJson,
					contentType : "application/json"
				})
				
				
				request.done(function(data){-
					console.log("Success: added");
					window.location.reload(true);
				})
				
				request.fail(function(jqXHR, textStatus){
					console.log("FAIL:  "+textStatus+" || "+jqXHR);
				})
			})
		})
		
/*------------------------------------CUSTOMER SIGNUP FORM-----------------------------------------*/		
$(function() {
			
			$("#customerSignUpform").submit(function(event) {
				event.preventDefault();
				
				var customerSignupObj = {
						customerName : $("#customer-username").val(),
						address : $("#customer-shipaddress").val(),
						password : $("#customer-phoneno").val(),
						contactNo : $("#customer-password").val(),
						emailId : $("#customer-e-address").val()
				}
				
				var customerSignupJson = JSON.stringify(customerSignupObj);
				console.log(customerSignupJson);
				
				var request = $.ajax({
					url : "/addCustomer",
					method : "POST",
					data : customerSignupJson,
					contentType : "application/json"
				})
				
				
				request.done(function(data){-
					console.log("Success: added");
				alert (customerSignupJson);
					/*window.location ="/customerlogin";*/
				})
				
				request.fail(function(jqXHR, textStatus){
					console.log("FAIL:  "+textStatus+" || "+jqXHR);
				})
			})
		})